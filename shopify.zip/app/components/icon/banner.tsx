export default function Banner() {
  return (
    <>
      <img
        src="https://gratisography.com/wp-content/uploads/2024/11/gratisography-augmented-reality-1170x780.jpg"
        className="  hover:animate-pulse overflow-y-scroll "
        width="100%"
        height="100%"
      ></img>
    </>
  );
}
